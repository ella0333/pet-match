Test photos for the Pet Match demo

Apart from Doraemon's, none of these photos are in any post, so each one is a fair test. Doraemon's photo comes from his owner's lost post, and the search compares it with found posts only.

try-with-i-found-a-pet: press I found a pet and upload one. Each cat's owner has a lost post, which should come up as the top match.

try-with-i-lost-a-pet: press I lost a pet and upload one. Someone has posted each dog as found, which should come up as the top match.

opt-in-demo-try-with-i-lost-a-pet: press I lost a pet and upload it. Doraemon was found by someone in the Opt-in demo group. With that group switched off, Doraemon's found post doesn't appear in the results; switch the group on and search again to see it come up.

The "where and when" box is optional. Photo credits are in CREDITS.txt.
